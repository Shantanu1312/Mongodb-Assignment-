from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
    id=int(input("Enter Employee ID :"))
    dt={}
    dt["_id"]=id

    for data in coll.find(dt):
        print("-"*50)
        print(data)
except:
    print("Error In Searching....")