from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
    id=int(input("Enter Employee ID :"))
    dp=input("Enter Department :")
    city=input("Enter City :")

    eid={}
    eid["_id"]=id

    dt={}
    dt["Department"]=dp
    dt["City"]=city

    update1={"$set":dt}
    


    coll.update_many(eid,update1)
    

    print("-"*50)
    for data in coll.find(eid):
        print(data)
except:
    print("updation Failed.....")