from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
    id=int(input("Enter Employee ID :"))
    sal=float(input("Enter Salary :"))

    eid={}
    eid["_id"]=id

    esal={}
    esal["Salary"]=sal

    update={"$set":esal}

    coll.update_one(eid,update)

    print("-"*50)
    for data in coll.find(eid):
        print(data)
except:
    print("updation Failed.....")