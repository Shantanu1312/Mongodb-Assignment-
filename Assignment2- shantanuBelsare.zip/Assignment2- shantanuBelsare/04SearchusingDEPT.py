from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
    dept=input("Enter Department :")
    dt={}
    dt["Department"]=dept

    for data in coll.find(dt):
        print("-"*120)
        print(data)
except:
    print("Error In Searching....")