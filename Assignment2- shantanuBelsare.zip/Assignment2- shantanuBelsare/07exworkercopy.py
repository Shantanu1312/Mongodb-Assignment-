from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll1=db["workers"]
coll2=db["exworkers"]

try:
    eid=int(input("Enter Employee ID :"))

    id={}
    id["_id"]=eid

    for a in coll1.find(id):
        coll2.insert_one(a)

    print("Adding Ex worker data  Successfully....")
    for data1 in coll2.find(id):
        print("-"*120)
        print(data1)


    coll1.delete_one(id)
    print("-"*100)
    print("Deleted exworker data in collection successfully....")
    for data2 in coll1.find():
        print("-"*120)
        print(data2)
   
except:
    print("Did not Copy")
