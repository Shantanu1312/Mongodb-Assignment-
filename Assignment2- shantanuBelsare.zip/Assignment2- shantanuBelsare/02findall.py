from pymongo  import MongoClient, collection

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
   for data in coll.find():
      print(data)
except:
    print("Error In Finding")