from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]


try:
   sa=float(input("Enter Enter Salary :"))

   dt={"Salary":{"$gte":sa}}
   for data in coll.find(dt):
        print("-"*100)
        print(data)
except:
    print("Finding Failed.....")


