from pymongo import MongoClient


client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
   id=int(input('Enter employee ID : '))
   nm=input('Enter  employee name : ')
   dep=input('Enter Department: ')
   pt=input('Enter Post : ')
   ct=input("Enter  City :")
   sal=float(input("Enter Salary :"))
   mob=int(input("Enter MobileNo :"))
   em=input("Enter Email :")

   dic={}
   dic["_id"]=id
   dic["Empname"]=nm
   dic["Department"]=dep
   dic["Post"]=pt
   dic["City"]=ct
   dic["Salary"]=sal
   dic["Mobile"]=mob
   dic["Email"]=em

   coll.insert_one(dic)
   print('New Employee added to workers collection')
   print("-"*50)
   for data in coll.find():
    print(data)
except:
    print("Data Adding Failed In Collection......")